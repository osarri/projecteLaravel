<html lang="es">
<head>
    <meta charset="utf-8">
    <title>CANAL CREADO</title>
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body class="p-3 mb-2">
    <a href="{{route('home')}}" class="btn btn-dark">Volver</a><br><br>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>Código</th>
                <th>Canal</th>
                <th>Programa</td>
                <th>Dia</th>
                <th>Hora</th>
            </tr>
        </thead>
        <tbody>
        @foreach($graellas as $graella)
        <tr>
        <th>{{$graella-> id}}</th>
        <th>@foreach($graella-> programas as $programa) 
                @foreach ($canals as $canal)
                    @if($programa->idCanal == $canal->id)
                    {{$canal->nameCanal}}
                    @endif
                @endforeach
            @endforeach
        </th>
        <th>
            @foreach($graella->programas as $programa) 
                {{$programa->namePrograma}}
            @endforeach
        </th>
        <th> {{$graella -> dia}}</th>
        <th> {{$graella -> hora}}</th>
        </tr>
        @endforeach
        </tbody>
</table>
</body>
</html>