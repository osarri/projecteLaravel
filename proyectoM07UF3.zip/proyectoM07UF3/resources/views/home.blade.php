@extends('layouts.app')

@section('content')
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <a href="{{route('canalsCreate')}}"><div style="color: black;" class="alert alert-info" role="alert">
                        <b>Crear un canal</b>
                    </div></a>
                    <a href="{{route('canalsEdit')}}"><div style="color: black;" class="alert alert-info" role="alert">
                        <b>Editar un canal</b>
                    </div></a>
                    <a href="{{route('programasCreate')}}"><div style="color: black;" class="alert alert-info" role="alert">
                        <b>Crear un programa</b>
                    </div></a>
                    <a href="{{route('graellaCreate')}}"><div style="color: black;" class="alert alert-info" role="alert">
                        <b>Crear una graella</b>
                    </div></a>
                    <a href="{{route('visualizar')}}"><div style="color: black;" class="alert alert-info" role="alert">
                        <b>Visualizar graellas</b>
                    </div></a>
                </div>
        </div>
    </div>
</div>
</body>
@endsection
