<html lang="es">
<head>
    <meta charset="utf-8">
    <title>CANAL CREADO</title>
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body class="p-3 mb-2" style="background-color: #474747">
    <a href="{{route('home')}}" class="btn btn-dark">Volver</a>
    <h1 class="bien">CANAL CREADO CORRECTAMENTE</h1>
</body>
</html>