<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body class="p-3 mb-2">
<a href="<?php echo e(route('home')); ?>" class="btn btn-dark">Volver</a><br><br>
<h2 class="titulo">Crear una graella</h3>
<form class="formulario" method="GET" action="<?php echo e(route('graellaStore')); ?>">
    <label for='id_programa'><b>Programa:</b></label>
    <select name="idPrograma" class="form-control"> 
        <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p-> id); ?>"><?php echo e($p-> namePrograma); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br><br>
    <label for='dia'><b>Dia:</b></label>
    <select class="form-control" name="dia">
        <option value="Dilluns">Dilluns</option>
        <option value="Dimarts">Dimarts</option>
        <option value="Dimecres">Dimecres</option>
        <option value="Dijous">Dijous</option>
        <option value="Divendres">Divendres</option>
        <option value="Dissabte">Dissabte</option>
        <option value="Diumenge">Diumenge</option>
    </select><br><br>
    <label for='hora'><b>Hora:</b></label>
    <input name="hora" type="text" class="form-control"><br><br>
    <input class="btn btn-secondary" type="submit" value="Crear Graella">
</form>
</body>
</html><?php /**PATH /home/oscar/Documentos/DAW/m07_web_servidor/uf3_collados/proyectoM07UF3/resources/views/graella/create.blade.php ENDPATH**/ ?>