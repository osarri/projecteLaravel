<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <a href="<?php echo e(route('CanalIndex')); ?>">Index</a><br>
                    <a href="<?php echo e(route('canalsCreate')); ?>">Crear un canal</a><br>
                    <a href="<?php echo e(route('canalsEdit')); ?>">Editar un canal</a><br>
                    <a href="<?php echo e(route('programasCreate')); ?>">Crear un programa</a><br>
                    <a href="<?php echo e(route('graellaCreate')); ?>">Crear una graella</a><br>
                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/proyectoM07UF3/resources/views/home.blade.php ENDPATH**/ ?>