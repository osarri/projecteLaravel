<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body class="p-3 mb-2">
<a href="<?php echo e(route('home')); ?>" class="btn btn-dark">Volver</a><br><br><div>
<h2 class="titulo">Crear un programa</h2>
<form class="formulario" method="GET" action="<?php echo e(route('programasStore')); ?>">
    <label for='namePrograma'><b>Nombre Programa:</b></label>
    <input class="form-control" name="namePrograma" type="text"><br>
    <label for='descripcio'><b>Descripció:</b></label>
    <input class="form-control" name="descripcio" type="text"><br>
    <label for='tipo'><b>Tipo:</b></label>
    <select class="form-control" name="tipo">
        <option value="documental">Documental</option>
        <option value="deportes">Deportes</option>
        <option value="serie">Serie</option>
        <option value="pelicula">Pelicula</option>
        <option value="concurso">Concurso</option>
        <option value="informativo">Informativo</option>
    </select><br>
    <label for='clasificacion'><b>Clasificacion:</b></label>
    <select class="form-control" name="clasificacion">
        <option value="todos los pubicos">Todos los públicos</option>
        <option value="+7">+7</option>
        <option value="+12">+12</option>
        <option value="+16">+16</option>
        <option value="+18">+18</option>
    </select><br>
    <label for='idCanal'><b>Canal:</b></label>
    <select class="form-control" name="idCanal"> 
        <?php $__currentLoopData = $idCanales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($idC-> id); ?>"><?php echo e($idC-> nameCanal); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <input class="btn btn-secondary" value="Crear Programa" type="submit"> 
</form>
</body>
</html><?php /**PATH /home/oscar/Documentos/DAW/m07_web_servidor/uf3_collados/proyectoM07UF3/resources/views/programas/create.blade.php ENDPATH**/ ?>