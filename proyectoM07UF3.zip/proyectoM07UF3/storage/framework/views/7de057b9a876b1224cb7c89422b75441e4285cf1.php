<html lang="es">
<head>
    <meta charset="utf-8">
    <title>CANAL CREADO</title>
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body class="p-3 mb-2">
    <a href="<?php echo e(route('home')); ?>" class="btn btn-dark">Volver</a><br><br>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>Código</th>
                <th>Canal</th>
                <th>Programa</td>
                <th>Dia</th>
                <th>Hora</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $graellas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graella): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <th><?php echo e($graella-> id); ?></th>
        <th><?php $__currentLoopData = $graella-> programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php $__currentLoopData = $canals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($programa->idCanal == $canal->id): ?>
                    <?php echo e($canal->nameCanal); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </th>
        <th>
            <?php $__currentLoopData = $graella->programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php echo e($programa->namePrograma); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </th>
        <th> <?php echo e($graella -> dia); ?></th>
        <th> <?php echo e($graella -> hora); ?></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
</table>
</body>
</html><?php /**PATH /home/oscar/Documentos/DAW/m07_web_servidor/uf3_collados/proyectoM07UF3/resources/views/graella/index.blade.php ENDPATH**/ ?>