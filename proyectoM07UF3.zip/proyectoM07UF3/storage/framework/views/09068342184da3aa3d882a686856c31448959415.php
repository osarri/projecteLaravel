<a href="<?php echo e(route('home')); ?>"><button>Volver</button></a><br><br>
<h2 style="text-align: center;">Crear una graella</h3>
<form style="margin-left: 30px;" method="get" method="GET" action="<?php echo e(route('graellaStore')); ?>">
    <label for='dia'>Dia:</label>
    <select name="dia">
        <option value="Dilluns">Dilluns</option>
        <option value="Dimarts">Dimarts</option>
        <option value="Dimecres">Dimecres</option>
        <option value="Dijous">Dijous</option>
        <option value="Divendres">Divendres</option>
        <option value="Dissabte">Dissabte</option>
        <option value="Diumenge">Diumenge</option>
    </select><br>
    <label for='hora'>Hora:</label>
    <input name="hora" type="text"><br>
    <input type="submit" value="Crear Graella">
</form><?php /**PATH /var/www/html/proyectoM07UF3/resources/views/graella/create.blade.php ENDPATH**/ ?>