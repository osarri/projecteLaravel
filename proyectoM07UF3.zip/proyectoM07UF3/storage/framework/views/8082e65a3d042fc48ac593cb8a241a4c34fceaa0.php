
<div>
    <br>
    <h2 style="text-align: center;">Editar un canal</h3>
    <?php if(count($errors) > 0): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form style="margin-left: 30px;" method="get" action="<?php echo e(action('CanalController@update')); ?>">
        <?php echo e(csrf_field()); ?>

        <h4>ID:</h4>        
        <input type="number" name="id" value="<?php echo e($canal->id); ?>" placeholder="Id del canal a editar..." /><br>
        <h4>Nombre del Canal:</h4>
        <input type="text" name="nameCanal" value="<?php echo e($canal->nameCanal); ?>" placeholder="Escribe el nombre..." /><br><br>
        <input type="submit" value="Editar" />
    </form>
</div><?php /**PATH /home/oscar/Documentos/DAW/m07_web_servidor/uf3_collados/priyectoM07UF3/resources/views/canals/edit.blade.php ENDPATH**/ ?>