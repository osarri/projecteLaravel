<form method="GET" action="<?php echo e(route('canalsStore')); ?>">
    <label for='nameCanal'>Nombre Canal</label>
    <input name="nameCanal" type="text"> 
    <input value="Enviar" type="submit"> 
</form>
<?php /**PATH /home/oscar/Documentos/DAW/m07_web_servidor/uf3_collados/priyectoM07UF3/resources/views/canals/create.blade.php ENDPATH**/ ?>