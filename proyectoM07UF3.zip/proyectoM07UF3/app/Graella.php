<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Graella extends Model
{ 
    protected $fillable = [
        "dia",
        "hora"
    ];

    public function programas(){
        return $this->belongsToMany('App\Programa');
    }  
}
