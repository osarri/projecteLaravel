<?php

namespace App\Http\Controllers;
use App\Graella;
use App\Programa;
use App\Canal;

use Illuminate\Http\Request;

class GraellaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $programas= Programa::all();
        $graellas= Graella::all();
        $canals = Canal::all();

        return view('graella.index', compact('programas','graellas','canals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programas = \DB::table('programas')->select('id', 'namePrograma')->get();
        return view('graella.create', compact('programas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nuevaGraella = new Graella([
            'dia' => $request->get('dia'),
            'hora' => $request->get('hora')
        ]);
        $nuevaGraella->save();
        $nuevaGraella ->programas()->attach($request->idPrograma);
        return redirect()->route('visualizar');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
